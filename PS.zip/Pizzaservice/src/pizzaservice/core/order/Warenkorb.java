package pizzaservice.core.order;

import java.util.ArrayList;
import java.util.Date;

public class Warenkorb implements Preis{

	//Attribute
	private final ArrayList<Pizza> pizzen;
	private final Date datum;
	
	public Warenkorb()
	{
		this.datum = new Date();
		this.pizzen = new ArrayList<>();
	}
	
	public ArrayList<Pizza> getPizzen() {
		return pizzen;
	}

	public Date getDatum() {
		return datum;
	}

	public ArrayList<Pizza> addPizza(Pizza pizza)
	{
		this.pizzen.add(pizza);
		return pizzen;
	}
	
	public ArrayList<Pizza> removePizza(Pizza pizza)
	{
		this.pizzen.remove(pizza);
		return pizzen;
	}

	@Override
	public double getPreis() {
		double gesPreis = 0;
		for(Pizza p : pizzen)
		{
			gesPreis += p.getPreis();
		}
		return gesPreis;
	}
	
}
