package pizzaservice.core.order;

public enum Toppings {
	PILZE,
	SALAMI,
	KAESE,
	SCHINKEN,
	TOMATEN,
	PAPRIKA,
	ANANAS,
	MOZZARELLA,
	THUNFISCH,
	ZWIEBELN,
	TOMATENSOSSE,
	HACKFLEISCH;
}
