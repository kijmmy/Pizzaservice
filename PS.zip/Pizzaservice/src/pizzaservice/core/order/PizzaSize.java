package pizzaservice.core.order;

public enum PizzaSize implements Preis{
	// SMALL.. ist sozusagen ein Objekt von PizzaSize
	SMALL(1, 2, 5.99),
	LARGE(2, 3, 8.99),
	XLARGE(2, 5, 12.99);

	// Attribute
	public final int parts;
	public final int toppings;
	private final double preis;

	// Konstruktor
	private PizzaSize(int parts, int toppings, double preis) {
		this.parts = parts;
		this.toppings = toppings;
		this.preis = preis;
	}

	@Override
	public double getPreis() {
		return preis;
	}
}
