package pizzaservice.core.order;

import java.util.Optional;

public class Kunde {

	// Attribute
	private String name;
	private String telefonnummer;
	private boolean lieferung;
	private String adresse;
	private Optional<Boolean> gesperrt;

	public Kunde(String name, String telefonnummer, boolean lieferung, String adresse) {
		this.name = name;
		this.telefonnummer = telefonnummer;
		this.lieferung = lieferung;
		this.adresse = adresse;
		this.gesperrt = Optional.empty();
	}

	public String getName() {
		return name;
	}

	public String getTelefonnummer() {
		return telefonnummer;
	}

	public boolean isLieferung() {
		return lieferung;
	}

	public String getAdresse() {
		return adresse;
	}

	public Optional<Boolean> getGesperrt() {
		return gesperrt;
	}

	public boolean isRegistered() {
		return gesperrt.isPresent();
	}

	public boolean isBlocked() {
		if (gesperrt.isPresent()) {
			return gesperrt.get();
		}
		return false;
	}
	
	public boolean register()
	{
		if(!gesperrt.isPresent())
		{
			gesperrt = Optional.of(false);
			return true;
		}
		return false;
	}
	
	public boolean toggleBlock()
	{
		if(!isRegistered())
		{
			return false;	
		}
		if(isBlocked())
		{
			gesperrt = Optional.of(false);
			return false;
		}
		else
		{
			gesperrt = Optional.of(true);
			return true;
		}
	}

}
