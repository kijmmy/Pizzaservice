package pizzaservice.core.order;

public interface Preis {
	public double getPreis();
}
