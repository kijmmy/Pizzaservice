package pizzaservice.core.order;

import java.util.ArrayList;

public class Pizza implements Preis{
	
	private final static double toppingPrice = 1.00; 
	
	// Attribute
	private final PizzaSize size;
	private String name = "";
	private final ArrayList<ArrayList<Toppings>> toppings;
	private final ArrayList<Toppings> extraToppings;

	// Konstruktor
	public Pizza(String name, PizzaSize size) {
		this.size = size;
		this.name = name;
		toppings = new ArrayList<>();
		extraToppings = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void addExtraTopping(Toppings topping) {
		extraToppings.add(topping);
	}

	public void removeExtraTopping(Toppings topping) {
		extraToppings.remove(topping);
	}

	
	public void addTopping(ArrayList<Toppings> topping) {
		if (size.parts > toppings.size()) {
			toppings.add(topping);
		}
	}
	
	public void removeTopping(ArrayList<Toppings> topping) {
		if (size.parts > toppings.size()) {
			toppings.remove(topping);
		}
	}

	public PizzaSize getSize() {
		return size;
	}

	public ArrayList<ArrayList<Toppings>> getToppings() {
		return toppings;
	}

	public ArrayList<Toppings> getExtraToppings() {
		return extraToppings;
	}

	@Override
	public double getPreis() {
		int toppingDiv = extraToppings.size() - size.toppings;
		return size.getPreis() + (toppingDiv > 0 ? toppingDiv * toppingPrice : 0);
	}

}
