package pizzaservice.core.intern;

import java.util.ArrayList;

public class Filiale {

	private ArrayList<Bestellung> bestellungen;
	private String bezeichnung;
	
	public Filiale(String bezeichnung)
	{
		this.bezeichnung = bezeichnung;
		this.bestellungen = new ArrayList<>();
	}

	public ArrayList<Bestellung> getBestellungen() {
		return bestellungen;
	}

	public void setBestellungen(ArrayList<Bestellung> bestellungen) {
		this.bestellungen = bestellungen;
	}

	public String getBezeichnung() {
		return bezeichnung;
	}
	
	public boolean addBestellung(Bestellung bestellung)
	{
		return this.bestellungen.add(bestellung);
	}
	
	public boolean removeBestellung(Bestellung bestellung)
	{
		return this.bestellungen.remove(bestellung);
	}
	
}
