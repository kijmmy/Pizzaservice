package pizzaservice.core.intern;

public enum Status {
	AUTH,
	NEW,
	BAKING,
	DELIVERY,
	FINISCHED,
	CANCELED;
}
