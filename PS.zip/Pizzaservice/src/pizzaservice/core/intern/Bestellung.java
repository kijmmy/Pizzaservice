package pizzaservice.core.intern;

import java.util.Date;

import pizzaservice.core.order.Kunde;
import pizzaservice.core.order.Preis;
import pizzaservice.core.order.Warenkorb;

public class Bestellung implements Preis{
	
	private Date datum;
	private Warenkorb warenkorb;
	private Kunde kunde;
	private Status status;
	
	public Bestellung(Kunde kunde,Warenkorb warenkorb, Filiale filiale)
	{
		this.kunde = kunde;
		this.warenkorb = warenkorb;
		this.datum = new Date();
		if(kunde.isRegistered())
		{
			this.status = Status.NEW;
		}
		else
		{
			this.status = Status.AUTH;
		}
		filiale.addBestellung(this);
	}
	
	public Status setStatus(Status status)
	{
		this.status = status;
		return status;
	}

	public Kunde getKunde() {
		return kunde;
	}

	public Status getStatus() {
		return status;
	}

	public Warenkorb getWarenkorb() {
		return warenkorb;
	}

	public Date getDatum() {
		return datum;
	}

	@Override
	public double getPreis() {
		return warenkorb.getPreis();
	}
	
	
}
