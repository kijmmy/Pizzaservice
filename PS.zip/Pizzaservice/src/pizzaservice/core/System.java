package pizzaservice.core;

import java.util.ArrayList;
import java.util.Arrays;

import pizzaservice.core.intern.Bestellung;
import pizzaservice.core.intern.Filiale;
import pizzaservice.core.intern.Status;
import pizzaservice.core.order.Kunde;
import pizzaservice.core.order.Warenkorb;

public class System {

	//Attribute
	private Filiale filiale;
	private ArrayList<Kunde> kunden;
	private ArrayList<Bestellung> bestellungen;
	
	
	public System()
	{
		this.filiale = new Filiale("Hauptfiliale");
		this.kunden = new ArrayList<>();
		this.bestellungen = new ArrayList<>();
	}

	public Filiale getFiliale() {
		return filiale;
	}

	public ArrayList<Kunde> getKunden() {
		return kunden;
	}

	public boolean addKunde(Kunde e) {
		return kunden.add(e);
	}

	public boolean removeKunde(Kunde o) {
		return kunden.remove(o);
	}
	
	public boolean remove(Bestellung bestellung) {
		return this.bestellungen.remove(bestellung);
	}

	public ArrayList<Bestellung> getBestellungen() {
		return bestellungen;
	}

	public boolean order(Kunde kunde, Warenkorb warenkorb, Filiale filiale)
	{
		bestellungen.add(new Bestellung(kunde, warenkorb, filiale));
		return true;
	}
	
	public Kunde getkunde(String telefonnummer) {
		for(Kunde k : kunden)
		{
			if(k.getTelefonnummer().equals(telefonnummer))
			{
				return k;
			}
		}
		return null;
	}
	
	public ArrayList<Bestellung> getBestellungen(Kunde kunde, Status... status)
	{
		ArrayList<Bestellung> filteredBestellungen = getBestellungen(status);
		ArrayList<Bestellung> tempBestellungen = new ArrayList<>();
		
		for(Bestellung b : filteredBestellungen)
		{
			if(b.getKunde() == kunde)
			{	
				tempBestellungen.add(b);
			}
		}
		
		return tempBestellungen;
	}
	
	public ArrayList<Bestellung> getBestellungen(Status... status)
	{
		ArrayList<Bestellung> tempBestellungen = new ArrayList<>();
		ArrayList<Status> statuse = new ArrayList<>();
		if(status.length > 0)
		{
			statuse.addAll(Arrays.asList(status));
		}
		
		for(Bestellung b : bestellungen)
		{
			if((statuse.contains(b.getStatus()) || statuse.isEmpty()))
			{	
				tempBestellungen.add(b);
			}
		}
		
		return tempBestellungen;
	}
}
