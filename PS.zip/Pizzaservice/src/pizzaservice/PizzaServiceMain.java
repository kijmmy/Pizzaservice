package pizzaservice;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.omg.CORBA.portable.ValueOutputStream;

import javafx.scene.chart.ValueAxis;
import pizzaservice.core.System;
import pizzaservice.core.order.Pizza;
import pizzaservice.core.order.PizzaSize;
import pizzaservice.core.order.Toppings;
import pizzaservice.core.order.Warenkorb;

import javax.swing.JTabbedPane;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JRadioButton;
import java.awt.Choice;
import java.awt.Color;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.lang.ProcessBuilder.Redirect;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JTree;

public class PizzaServiceMain extends JFrame {

	private JPanel contentPane;
	private JTextField tFName;
	private JTextField tFStrasse;
	private JTextField tFPlz;
	private JTextField tFOrt;
	private JTextField tFTelefon;
	private final Action action = new SwingAction();
	private static System system = new System();
	private Warenkorb warenkorb = new Warenkorb();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PizzaServiceMain frame = new PizzaServiceMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static String format(double i)
	{
		DecimalFormat f = new DecimalFormat("#0.00");
		double toFormat = ((double)Math.round(i*100))/100;
		return f.format(toFormat);
	}
	
	/**
	 * Create the frame.
	 */
	public PizzaServiceMain() {
	
		
		ButtonGroup bgPizza = new ButtonGroup();
		ButtonGroup bgSize = new ButtonGroup();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1023, 594);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(0, 0, 1007, 555);
		contentPane.add(tabbedPane);
		DefaultListModel dlm1 = new DefaultListModel<>();
		DefaultListModel dlmWk = new DefaultListModel<>();
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Kunde", null, panel, null);
		panel.setLayout(null);
		
		JLabel lblWarenkorb = new JLabel("Warenkorb");
		lblWarenkorb.setBounds(529, 33, 196, 28);
		panel.add(lblWarenkorb);
		
		JLabel lblAngebot = new JLabel("Angebot");
		lblAngebot.setBounds(48, 44, 46, 14);
		panel.add(lblAngebot);
		
		JTextPane txtpnPizzaSalami = new JTextPane();
		txtpnPizzaSalami.setText("Pizza Salami");
		txtpnPizzaSalami.setBounds(48, 76, 238, 62);
		panel.add(txtpnPizzaSalami);
		
		JTextPane txtpnPizzaMargharita = new JTextPane();
		txtpnPizzaMargharita.setText("Pizza Margherita ");
		txtpnPizzaMargharita.setBounds(48, 149, 238, 62);
		panel.add(txtpnPizzaMargharita);
		
		JTextPane txtpnPizzaHawaii = new JTextPane();
		txtpnPizzaHawaii.setText("Pizza Hawaii");
		txtpnPizzaHawaii.setBounds(48, 222, 238, 62);
		panel.add(txtpnPizzaHawaii);
		
		JTextPane textPane_3 = new JTextPane();
		textPane_3.setBounds(350, 76, 157, 28);
		panel.add(textPane_3);
		
		JTextPane textPane_4 = new JTextPane();
		textPane_4.setBounds(350, 115, 157, 28);
		panel.add(textPane_4);
		
		JRadioButton rdbtnSalami = new JRadioButton("");
		rdbtnSalami.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				textPane_3.setText(txtpnPizzaSalami.getText());
			}
		});
		rdbtnSalami.setBounds(18, 76, 24, 23);
		panel.add(rdbtnSalami);
		bgPizza.add(rdbtnSalami);
		
		JRadioButton rdbtnMargherita = new JRadioButton("");
		rdbtnMargherita.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textPane_3.setText(txtpnPizzaMargharita.getText());
			}
		});
		rdbtnMargherita.setBounds(18, 149, 24, 23);
		panel.add(rdbtnMargherita);
		bgPizza.add(rdbtnMargherita);
		
		JRadioButton rdbtnHawaii = new JRadioButton("");
		rdbtnHawaii.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textPane_3.setText(txtpnPizzaHawaii.getText());
			}
		});
		rdbtnHawaii.setBounds(18, 222, 24, 23);
		panel.add(rdbtnHawaii);
		bgPizza.add(rdbtnHawaii);
		
		JLabel lblGre = new JLabel("Größe");
		lblGre.setBounds(48, 295, 46, 14);
		panel.add(lblGre);
		
		JRadioButton rdbtnSmall = new JRadioButton("SMALL");
		rdbtnSmall.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textPane_4.setText(rdbtnSmall.getText());
			}
		});
		rdbtnSmall.setBounds(48, 316, 76, 23);
		panel.add(rdbtnSmall);
		bgSize.add(rdbtnSmall);
		
		JRadioButton rdbtnLarge = new JRadioButton("LARGE");
		rdbtnLarge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textPane_4.setText(rdbtnLarge.getText());
			}
		});
		rdbtnLarge.setBounds(126, 316, 82, 23);
		panel.add(rdbtnLarge);
		bgSize.add(rdbtnLarge);
		
		JRadioButton rdbtnXl = new JRadioButton("XLARGE");
		rdbtnXl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textPane_4.setText(rdbtnXl.getText());
			}
		});
		rdbtnXl.setBounds(210, 316, 76, 23);
		panel.add(rdbtnXl);
		bgSize.add(rdbtnXl);
		
		JLabel lblToppings = new JLabel("Toppings");
		lblToppings.setBounds(48, 345, 76, 14);
		panel.add(lblToppings);
		
		//DropDown Menü für die Auswahl der Toppings
		Choice choice = new Choice();
		choice.setBounds(48, 367, 104, 20);
		panel.add(choice);
		
		JLabel lblKosten = new JLabel("0.00");
		lblKosten.setBounds(658, 423, 67, 14);
		panel.add(lblKosten);
		
		JLabel lblAktuelleAuswahl = new JLabel("Aktuelle Auswahl");
		lblAktuelleAuswahl.setBounds(350, 44, 127, 14);
		panel.add(lblAktuelleAuswahl);
		
		JLabel lblToppings_1 = new JLabel("Toppings inkl.");
		lblToppings_1.setBounds(350, 158, 110, 14);
		panel.add(lblToppings_1);
		
		JList list = new JList();
		list.setBounds(350, 183, 157, 202);
		panel.add(list);
		
		//Button zum Hinzufügen des zuvor ausgewählten Toppings
		JButton btnHinzufgen = new JButton("Auswahl");
		btnHinzufgen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				dlm1.addElement(choice.getSelectedItem());
				list.setModel(dlm1);
			}
		});
		btnHinzufgen.setBounds(172, 364, 89, 23);
		panel.add(btnHinzufgen);
		
		JButton btnToppingsLschen = new JButton("Toppings löschen");
		btnToppingsLschen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				dlm1.removeElement(list.getSelectedValue());
			}
		});
		btnToppingsLschen.setBounds(350, 389, 157, 23);
		panel.add(btnToppingsLschen);
		
		JLabel lblLieferadresse = new JLabel("Lieferadresse");
		lblLieferadresse.setBounds(763, 44, 104, 14);
		panel.add(lblLieferadresse);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(762, 76, 46, 14);
		panel.add(lblName);
		
		JLabel lblStrae = new JLabel("Straße");
		lblStrae.setBounds(763, 110, 46, 14);
		panel.add(lblStrae);
		
		JLabel lblPlz = new JLabel("PLZ");
		lblPlz.setBounds(763, 149, 46, 14);
		panel.add(lblPlz);
		
		JLabel lblOrt = new JLabel("Ort");
		lblOrt.setBounds(763, 184, 46, 14);
		panel.add(lblOrt);
		
		JLabel lblTelefon = new JLabel("Telefon");
		lblTelefon.setBounds(762, 222, 46, 14);
		panel.add(lblTelefon);
		
		tFName = new JTextField();
		tFName.setBounds(818, 73, 143, 20);
		panel.add(tFName);
		tFName.setColumns(10);
		
		tFStrasse = new JTextField();
		tFStrasse.setColumns(10);
		tFStrasse.setBounds(818, 107, 143, 20);
		panel.add(tFStrasse);
		
		tFPlz = new JTextField();
		tFPlz.setColumns(10);
		tFPlz.setBounds(819, 146, 143, 20);
		panel.add(tFPlz);
		
		tFOrt = new JTextField();
		tFOrt.setColumns(10);
		tFOrt.setBounds(819, 181, 143, 20);
		panel.add(tFOrt);
		
		tFTelefon = new JTextField();
		tFTelefon.setColumns(10);
		tFTelefon.setBounds(818, 219, 143, 20);
		panel.add(tFTelefon);
		
		JList listWarenkorb = new JList();
		listWarenkorb.setBounds(529, 72, 196, 313);
		panel.add(listWarenkorb);
		
		JButton btnBestellungAbschicken = new JButton("Bestellung abschicken");
		btnBestellungAbschicken.setBounds(763, 316, 198, 62);
		panel.add(btnBestellungAbschicken);
		
		JButton btnZumWarenkorbHinzufgen = new JButton("Zum Warenkorb hinzufügen");
		
		btnZumWarenkorbHinzufgen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			
			{
				
				if((textPane_3.getText().isEmpty()) || (textPane_4.getText().isEmpty()))
				{
					JOptionPane.showMessageDialog(null, "Leider ist keine vollständige Pizza ausgewählt worden.");
				}
				else
				{
					
					Pizza pizza = new Pizza(textPane_3.getText(),PizzaSize.valueOf(textPane_4.getText()));
					warenkorb.addPizza(pizza);
					
					listWarenkorb.setModel(dlmWk);
					lblKosten.setText(String.valueOf(format(warenkorb.getPreis())));
					//dlmWk.addElement(warenkorb + " " + getSize() + " " + warenkorb.getPreis() + "€");
					
					
					//Pizza pizza = new Pizza(PizzaSize.valueOf(textPane_4.getText().touppercase()));
					/*pizza.addExtraTopping(topping);
					pizza.getPreis();
					warenkorb.addPizza(pizza);
					warenkorb.getPreis();*/
					/*
					if(textPane_4.getText().equals("Small"))
					{
						
					}
					
					else if (textPane_4.getText().equals("Large")) {
						sizeCosts = 8.99;
					}
					else if (textPane_4.getText().equals("XL"))
					{
						sizeCosts = 12.99;
					}
					dlmWk.addElement(textPane_3.getText() + " " + textPane_4.getText() + " " + sizeCosts + "€");
					*/
				}
			}
		});
		btnZumWarenkorbHinzufgen.setBounds(48, 440, 459, 62);
		panel.add(btnZumWarenkorbHinzufgen);
		
		JButton btnPizzaLschen = new JButton("Pizza löschen");
		btnPizzaLschen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				dlmWk.removeElement(listWarenkorb.getSelectedValue());
				listWarenkorb.setModel(dlmWk);
				//lblKosten.setText(String.valueOf(Double.parseDouble(lblKosten.getText()) - sizeCosts));
			}
		});
		btnPizzaLschen.setBounds(529, 389, 196, 23);
		panel.add(btnPizzaLschen);
		
		JLabel lblGesamtkosten = new JLabel("Gesamtkosten in €: ");
		lblGesamtkosten.setBounds(529, 423, 104, 14);
		panel.add(lblGesamtkosten);
		

		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Koch", null, panel_1, null);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Mitarbeiter", null, panel_2, null);
		panel_2.setLayout(new BoxLayout(panel_2, BoxLayout.X_AXIS));
		for(Toppings t: Toppings.values())
		{
			choice.add(t.name().substring(0, 1) + t.name().substring(1, t.name().length()).toLowerCase());
		}
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "Bestellung abschicken");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
